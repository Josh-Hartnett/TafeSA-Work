/*
 * 13-03-2022 ---- Joshua Hartnett / hart0397
 *
 * Programming Task 1
 *
 */
#include <iostream>
#include <cstdlib> //Contains atoi function used to convert a string into integer

using namespace std;

int main(int argc, char *argv[]) {
    //Value on the argument line at [0] will be the file path, [1] will be the 'quitegood', so we begin at [2].
    const int limit = argc > 1 ? atoi(argv[2]) : 10000; //If no arguments are made we have defaults set
    int badness = argc > 1 ? atoi(argv[3]) : 0;

    if(badness < 0) { //If badness is less than 0, e.g. a negative number...
        badness = abs(badness);
        //Turn the badness value into its absolute version, as we know this badness value has to be a negative for this block to execute.
        int count = 0; //Create a counter to count the 'quitegood' numbers for level 4, instead of displaying them.
        for (int number = 2; number < limit; number++) {
            int total = 1;


            for (int factor = 2; factor * factor <= number; factor++) {
                if (number % factor == 0) {
                    total += factor;
                    if(factor * factor != number) {
                        total += number / factor;
                    }
                }
            }

            if (number >= (total - badness) && number <= (total + badness))
            {
                count++;
            }
        }
        cout << count; //Display our counter once the limit has been reached

    } else {
        for (int number = 2; number < limit; number++) {
            int total = 1;

            for (int factor = 2; factor * factor <= number; factor++) {
                if (number % factor == 0) {
                    total += factor;
                    if(factor * factor != number) {
                        total += number / factor;
                    }
                }
            }

            if (number >= (total - badness) && number <= (total + badness))
            {
                cout << number << " "; //Instead of a counter here we have the system display the number that matches the criteria.
            }
        }
    }
}
