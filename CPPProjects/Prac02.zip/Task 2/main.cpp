#include <iostream>
#include <cctype>
using namespace std;

int main() {
    string singleDigits[10] = {" ", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"};
    int singleDigitLength = (sizeof(singleDigits) / sizeof(string)) - 1;
    string tensDigits[10] = {" ", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC"};
    int tensDigitLength = (sizeof(tensDigits) / sizeof(string)) - 1;
    string hundredsDigits[10] = {" ", "C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM"};
    int hundredsDigitLength = (sizeof(hundredsDigits) / sizeof(string)) - 1;
    string thousandthsDigits[4] = {" ", "M", "MM", "MMM"};
    int thousandthsDigitLength = (sizeof(thousandthsDigits) / sizeof(string)) -1;
    string arabicNum[10] = {"0", "1", "2","3","4","5","6","7","8","9"};
    int arabicNumLength = (sizeof(arabicNum) / sizeof(string)) -1;


    string input;
    cin>>(input);
    int inputLength = sizeof(input) / sizeof(int);

    //Code loops through to capitalise
    for(int i = 0; i < inputLength; i++) {
        input[i] = toupper(input[i]);

        if(inputLength >= 1) {
            input[i+1] = toupper(input[i+1]);
        }
    }

    string inputArray[inputLength];
    for(int i = 0; i < inputLength; i++) {
        inputArray[i] = input[i];
    }

    //Match output loops
    int resultThousand = 0;
    int resultHundred = 0;
    int resultTen = 0;
    int resultOne = 0;
    bool valueCheck = false;


    for(int i = singleDigitLength; i > 0; i--) {
        if(input == singleDigits[i]) {
            resultOne += i * 1;
            valueCheck = true;
        }
    }
    for(int i = tensDigitLength; i > 0; i--) {
        if (input == tensDigits[i]) {
            resultTen = i * 10;
            valueCheck = true;
        }
    }
    for(int i = hundredsDigitLength; i > 0; i--) {
        if (input == hundredsDigits[i]) {
            resultHundred += i * 100;
            valueCheck = true;
        }
    }
    for(int i = thousandthsDigitLength; i > 0; i--) {
        if(input == thousandthsDigits[i]) {
            resultThousand += i * 1000;

            valueCheck = true;
        }
    }


    if(!valueCheck) {
        for(int i = thousandthsDigitLength; i > 0; i--) {
            for(int j = 0; j < thousandthsDigitLength; j++) {
                if(inputArray[j] == thousandthsDigits[i]) {
                    resultThousand += i * 1000;
                }
            }
        }
    }


    if(!valueCheck) {
        for(int i = hundredsDigitLength; i > 0; i--) {
            for(int j = 0; j < hundredsDigitLength; j++) {
                if(inputArray[j] == hundredsDigits[i]) {
                    if(resultHundred > i) {
                        resultHundred -= i;
                    } else {
                        resultHundred += i * 100;
                    }
                }
            }
        }
    }

    if(!valueCheck) {
        for(int i = tensDigitLength; i > 0; i--) {
            for(int j = 0; j < tensDigitLength; j++) {
                if(inputArray[j] == tensDigits[i]) {
                    if(resultTen > i) {
                        resultTen -= i;
                    } else {
                        resultTen += i * 10;
                    }
                }
            }
        }
    }
    if(!valueCheck) {
        for(int i = singleDigitLength; i > 0; i--) {
            for(int j = 0; j < singleDigitLength; j++) {
                if(inputArray[j] == singleDigits[i]) {
                    if (resultOne > i) {
                        resultOne -= i;
                    } else {
                        resultOne += i * 1;
                    }
                }
            }
        }
    }


    int result = resultThousand + resultHundred + resultTen + resultOne;
    cout << result << endl;

    return 0;
}
