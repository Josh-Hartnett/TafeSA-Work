/**
 * Computer Programming 2 (COMP2711, COMP8801)
 * Practical 2: Roman Numbers
 */

#include <iostream>
#include <cctype>
#include <fstream>
using namespace std;

int main(int argc, char *argv[])
{

    const int arguments = argc > 1 ? atoi(argv[2]) : 10000;
    string singleDigits[10] = {" ", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"};
    int singleDigitLength = sizeof(singleDigits) / sizeof(string);
    string tensDigits[10] = {" ", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC"};
    int tensDigitLength = sizeof(tensDigits) / sizeof(string);
    string hundredsDigits[10] = {" ", "C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM"};
    int hundredsDigitLength = sizeof(hundredsDigits) / sizeof(string);
    string thousandthsDigits[4] = {" ", "M", "MM", "MMM"};
    int thousandthsDigitLength = sizeof(thousandthsDigits) / sizeof(string);



    string input;
    while(getline(cin, input)) {
        int inputLength = input.size();
        int resultThousand = 0;
        int resultHundred = 0;
        int resultTen = 0;
        int resultOne = 0;
        bool valueCheck = false;

        //Code loops through to capitalise
        for (int i = 0; i < inputLength; i++) {
            input[i] = toupper(input[i]);
        }

        string inputArray[inputLength];
        for(int i = 0; i < inputLength; i++) {
            inputArray[i] = input[i];
        }

        for (int i = thousandthsDigitLength - 1; i != 0; i--) {
            if (input == thousandthsDigits[i]) {
                resultThousand += i * 1000;
                valueCheck = true;
            }
            if(!valueCheck) {
                for(int k = thousandthsDigitLength -1; k > 0; k--) {
                    for(int j = 0; j < thousandthsDigitLength -1; j++) {
                        if(inputArray[j] == thousandthsDigits[k]) {
                            inputArray[j] = "";
                            resultThousand += k * 1000;
                        }
                    }
                }
            }

        }


        for (int i = hundredsDigitLength - 1; i != 0; i--) {
            if (input == hundredsDigits[i]) {
                resultHundred += i * 100;
                valueCheck = true;
            }
            if(!valueCheck) {
                for(int k = hundredsDigitLength -1; k > 0; k--) {
                    for(int j = 0; j < hundredsDigitLength -1; j++) {
                        if(inputArray[j] == hundredsDigits[k]) {
                            inputArray[j] = "";
                            resultHundred += k * 100;
                        }
                    }
                }
            }
        }



        for (int i = tensDigitLength - 1; i != 0; i--) {
            if (input == tensDigits[i]) {
                resultTen = i * 10;
                valueCheck = true;
            }
            if(!valueCheck) {
                for(int k = tensDigitLength -1; k > 0; k--) {
                    for(int j = 0; j < tensDigitLength -1; j++) {
                        if(inputArray[j] == tensDigits[k]) {
                            inputArray[j] = "";
                            resultTen += k * 10;
                        }
                    }
                }
            }
        }


        for (int i = singleDigitLength - 1; i != 0; i--) {
            if (input == singleDigits[i]) {
                resultOne += i * 1;
                valueCheck = true;
            }
            if(!valueCheck) {
                for(int k = singleDigitLength -1; k > 0; k--) {
                    for(int j = 0; j < singleDigitLength -1; j++) {
                        if(inputArray[j] == singleDigits[k]) {
                            resultOne += k;
                            inputArray[j] = "";
                        }

                    }
                }
            }
        }


        cout << resultOne << ", " << resultTen << ", " << resultHundred << ", " << resultThousand << endl;
        int result = resultThousand + resultHundred + resultTen + resultOne;
        cout << result << endl;
    }
}
