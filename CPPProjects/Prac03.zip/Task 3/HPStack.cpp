//
// Created by joshh on 19/04/2022.
//

#include "HPStack.h"
//Level 1
//Initialise array
HPStack::HPStack() {
    for(int i = 0; i < 4; i++) {
        array[i] = 0;
    }
}
//Set push method - Push all values up one and store a value into X
void HPStack::push(double input) {
    array[3] = array[2];
    array[2] = array[1];
    array[1] = array[0];
    array[0] = input;
}
//Set pop method - Drop all values down 1 level and return the old X value (T is not cleared)
double HPStack::pop() {
    double output = array[0];
    array[0] = array[1];
    array[1] = array[2];
    array[2] = array[3];
    return output;
}
//Set peek method - Return the current X value, which is array[0] as set when we used push()
double HPStack::peek() {
    return array[0];
}
//Level 3
//Set the memory
void HPStack::set_memory(double input) {
    memory = input;
}
//Return the value stored within the memory
double HPStack::get_memory() {
    return memory;
}
//Level 4
//This will swap the first and second values, changing the order of calculations. We need a temporary variable in order to successfully compute the exchange.
void HPStack::swap() {
    double tempVar;
    tempVar = array[0];
    array[0] = array[1];
    array[1] = tempVar;
}
//Similarly as to above we need another temporary variable, as we move all the values down but set the last element in the array as the previous first.
void HPStack::roll() {
    double tempVar;
    tempVar = array[0];
    array[0] = array[1];
    array[1] = array[2];
    array[2] = array[3];
    array[3] = tempVar;
}
//Here we move all values up, while preserving x (array[0]) and discarding t (array[3]).
void HPStack::enter() {
    array[3] = array[2];
    array[2] = array[1];
    array[1] = array[0];
}