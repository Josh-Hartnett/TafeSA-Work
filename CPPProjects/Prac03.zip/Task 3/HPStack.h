//
// Created by joshh on 19/04/2022.
//

#ifndef TASK_3_HPSTACK_H
#define TASK_3_HPSTACK_H


class HPStack {
public:
    //Level 1
    HPStack();
    void push(double);
    double pop();
    double peek();
    double array[4];

    //Level 3
    double memory;
    void set_memory(double);
    double get_memory();

    //Level 4
    void swap();
    void roll();
    void enter();
};


#endif //TASK_3_HPSTACK_H
