#include <iostream>
#include <sstream>
#include <string>
#include <math.h>
#include "HPStack.h"

using namespace std;
//Level 1
int main(int argc, char *argv[]) {
    HPStack stack;
    string input;

    while(getline(cin, input)) {
        stringstream expression(input);
        string token;
        while(expression >> token) {

            //If the token of our input is equal to a digit, push it into the array
            if(isdigit(token[0])) {
                stack.push(atof(token.data()));
            }

            //Else if the token of our input is not equal to a digit and equal to an expression, perform the calculations.
            else if (token == "+") {
                double x = stack.pop();
                double y = stack.pop();
                stack.push(y + x);
            }

            else if (token == "-") {
                double x = stack.pop();
                double y = stack.pop();
                stack.push(y - x);
            }

            else if (token == "*") {
                double x = stack.pop();
                double y = stack.pop();
                stack.push(y * x);
            }

            else if (token == "/") {
                double x = stack.pop();
                double y = stack.pop();
                stack.push(y / x);
            }
            //End level 1
            //Start level 2
            else if(token == "pi" || token == "PI") {
                stack.push(M_PI);
            }

            else if(token == "chs" || token == "CHS") {
                double x = stack.pop();
                stack.push(x * -1);
            }

            else if (token == "recip" || token == "RECIP") {
                double x = stack.pop();
                stack.push(1 / x);
            }

            else if (token == "log" || token == "LOG") {
                double x = stack.pop();
                stack.push(log10(x));
            }

            else if (token == "ln" || token == "LN") {
                double x = stack.pop();
                stack.push(log(x));
            }

            else if (token == "exp" || token == "EXP") {
                double x = stack.pop();
                stack.push(exp(x));
            }

            else if (token == "sqrt" || token == "SQRT") {
                double x = stack.pop();
                stack.push(sqrt(x));
            }

            else if (token == "sin" || token == "SIN") {
                double x = stack.pop();
                stack.push(sin(x));
            }

            else if (token == "cos" || token == "COS") {
                double x = stack.pop();
                stack.push(cos(x));
            }

            else if (token == "tan" || token == "TAN") {
                double x = stack.pop();
                stack.push(tan(x));
            }

            else if (token == "arcsin" || token == "ARCSIN") {
                double x = stack.pop();
                stack.push(asin(x));
            }

            else if (token == "arccos" || token == "ARCCOS") {
                double x = stack.pop();
                stack.push(acos(x));
            }

            else if (token == "arctan" || token == "ARCTAN") {
                double x = stack.pop();
                stack.push(atan(x));
            }

            else if (token == "pow" || token == "POW") {
                double x = stack.pop();
                double y = stack.pop();
                stack.push(pow(x, y));
            }
            //End level 2
            //Start level 3
            else if (token == "sto" || token == "STO") {
                double x = stack.peek();
                stack.set_memory(x);
            }

            else if (token == "rcl" || token == "RCL") {
                double x = stack.get_memory();
                stack.push(x);
            }

            else if (token == "clr" || token == "CLR") {
                for(int i = 0; i < 4; i++) {
                    stack.push(0);
                }
            }

            else if (token == "clx" || token == "CLx") {
                stack.pop();
            }
            //End level 3
            //Start level 4
            else if (token == "swap" || token == "SWAP") {
                stack.swap();
            }

            else if (token == "roll" || token == "ROLL") {
                stack.roll();
            }

            else if (token == "enter" || token == "ENTER") {
                stack.enter();
            }
            //End level 4
        }
        //Stack.peek() returns array[0] which should be the correct number after the calculations.
        cout << stack.peek() << endl;
    }
    return 0;

}
