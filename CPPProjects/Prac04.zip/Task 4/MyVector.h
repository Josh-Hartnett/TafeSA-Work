//
// Created by joshh on 21/04/2022.
//

#ifndef MAIN_CPP_MYVECTOR_H
#define MAIN_CPP_MYVECTOR_H
#include <algorithm>
#include <string>
#include <vector>

using namespace std;


template <class T>
class MyVector {
public:
    typedef T* iterator; // creates an alias of the T* type called iterator
    MyVector() {
        items = new T[1];
        used = 0;
        capacity = 1;
    };
    iterator begin() {
        return items;
    };
    iterator end() {
        return items + used;
    };
    int size() {
        return used;
    };
    void insert (iterator position, const T& item) {
        //Dynamic allocation
        if(used == capacity) {
            T* temp = new T[2 * used];

            for (int i = 0; i < capacity; i++) {
                temp[i] = items[i];
            }

            delete[] items;
            capacity *= 2;
            items = temp;
        }

        items[used] = item;
        used++;
    };

private:
    T* items;
    int used;
    int capacity;
};

struct WordInfo {
    string text;
    int counter =0;
};

#endif //MAIN_CPP_MYVECTOR_H

/*Dynamic Allocation
 * //
// Created by joshh on 21/04/2022.
//

#ifndef MAIN_CPP_MYVECTOR_H
#define MAIN_CPP_MYVECTOR_H
#include <algorithm>
#include <string>
#include <vector>

using namespace std;


template <class T>
class MyVector {
public:
    typedef T* iterator; // creates an alias of the T* type called iterator
    MyVector() {
        items = new T[1];
        used = 0;
        capacity = 1;
    };
    iterator begin() {
        return items;
    };
    iterator end() {
        return items + used;
    };
    int size() {
        return used;
    };
    void insert (iterator position, const T& item) {
        //Dynamic allocation
        if(used == capacity) {
            T* temp = new T[2 * used];

            for (int i = 0; i < capacity; i++) {
                temp[i] = items[i];
            }

            delete[] items;
            capacity *= 2;
            items = temp;
        }

        items[used] = item;
        used++;
    };

private:
    T* items;
    int used;
    int capacity;
};

struct WordInfo {
    string text;
    int counter =0;
};

#endif //MAIN_CPP_MYVECTOR_H
*/