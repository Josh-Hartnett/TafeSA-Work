/*
 * Computer Programming 2 (COMP2711, COMP8801)
 * Practical 4: Words
 * Joshua Hartnett / hart0397 - 20/04/2022
 */

#include <iostream>
#include <string>
#include <unistd.h>
#include <vector>
#include <algorithm>
#include "MyVector.h"

using namespace std;

int main(int argc, char** argv)
{
    enum { total, unique, individual } mode = total;
    for (int c; (c = getopt(argc, argv, "tui")) != -1;) {
        switch(c) {
            case 't':
                mode = total;
                break;
            case 'u':
                mode = unique;
                break;
            //Level 3
            case 'i':
                mode = individual;
        }
    }

    argc -= optind;
    argv += optind;

    string word;
    //Level 1
    vector<string> input;
    //Level 2
    MyVector<string> VecInput;
    //Level 3
    vector<WordInfo> indInput;
    int count = 0;
    while (cin >> word) {
        count += 1;
        /*Level 1
        if(find(input.begin(), input.end(), word) != input.end()) {
            //Here we are saying the only time a word should be inserted into our input vector is when it is not already in the vector.
        } else {
            input.push_back(word);
        }*/
        //Level 2
        if(find(VecInput.begin(), VecInput.end(), word) != VecInput.end()) {

        } else {
            VecInput.insert(VecInput.end(), word);
        }

        //Level 3
        WordInfo temp;
        temp.text = word;
        temp.counter = 1;


        for(int i = 0; i < indInput.size(); i++) {
            if(temp.text == indInput[i].text) {
                temp.counter = indInput[i].counter + 1;
                indInput.erase(indInput.begin()+i);
            }
        }

        indInput.push_back(temp);

        //Simple insertion sort
        for(int i = 0; i < indInput.size(); i++) {
            WordInfo sort;
            sort.text = indInput[i].text;
            sort.counter = indInput[i].counter;

            int j;
            for(j=i; j>0 && indInput[j].text < indInput[j-1].text;) {
                swap(indInput[j-1], indInput[j]);
                j--;
            }
        }
    }
    switch (mode) {
        case total:
            cout << "Total: " << count << endl;
            break;
        case unique:
            /*Level 1
            //We can use input.size() as the size is equal to the number of unique words.
            cout << "Unique: " << input.size() << endl;*/
            //Level 2
            cout << "Unique: " << VecInput.size() << endl;
            break;
        //Level 3
        case individual:
            //Insertion sort which compares two WordInfo types


            for(int i = 0; i < indInput.size(); i++) {
                cout << indInput[i].text << " : " << indInput[i].counter << endl;
            }
            break;
    }
    return 0;
}