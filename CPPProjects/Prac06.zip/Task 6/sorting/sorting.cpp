#include <cstdlib>
#include <getopt.h>
#include <iostream>
#include <string>

using namespace std;

static long comparisons = 0;
static long swaps = 0;

void swap(int* a, int* b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

void selectionSort(int* first, int* last)
{
    for(int* i = first; i < last -1; i++) {
        int* min = i;
        for(int* j = i+1; j < last; j++) {
            comparisons++;
            if(*j < *min) {
                *min = *j;
            }
        }
        swap(*first+i, *first+min);
        swaps++;
    }
}

void insertionSort(int* first, int* last)
{
    //Failed attempt at faster insertion sort
//    for (int* i = first + 1; i < last; ++i) {
//        int t = *i;
//        int* j;
//        for (j = i; *j > *first && t < *(j-1); --j) {
//            *j = *(j-1);
//        }
//        *j = t;
//    }
    for(int* i = first +1; i < last; ++i) {
        for(int* j = i; j > first; --j) {
            comparisons++;
            if(*j < *(j-1)) {
                swap(*j, *(j-1));
                swaps++;
            }
        }
    }
}

int* partition(int* first, int* last) {
    /*To improve the quick sort, the pivot will be modified.

    The changes below tell the quick sort pivot to first calculate last-first, which
    will minus the two memory addresses and show the array size. The array size is then
    divided by two, to get half the size of the array. The last variable in the array (last)
    is then reduced by half of the array, or ((last-first)/2)).

    This then makes the pivot always begin at the middle of the array. Another necessary
    change occurs at the end of the partition function, where swap(*(last-1), *i) becomes
    swap(pivot, *i). This change happens because last-1 is no longer the pivot. */
    //int pivot = *(last-1);
    int pivot = *(last - ((last-first)/2));

    int* i = first;
    int* j = last;
    for(;;) {
        while(*i < pivot && i < last) {
            ++i;
            comparisons++;
        }
        while(*j >= pivot && j > first) {
            --j;
            comparisons++;
        }
        if(i >= j) {
            break;
        }
        swap(*i, *j);
        swaps++;
    }
    //swap(*(last-1), *i)
    swap(pivot, *i);
    swaps++;
    return i;
}


void quickSort(int* first, int* last)
{
    if(last - first <= 1) {
        return;
    }

    int* pivot = partition(first, last);
    quickSort(first, pivot);
    quickSort(pivot+1, last);
}


int main(int argc, char** argv)
{
    string algorithm = "selection";
    string dataset = "random";

    for (int c; (c = getopt(argc, argv, "ravqsin")) != -1;) {
        switch (c) {
        case 'r':
            dataset = "random";
            break;
        case 'a':
            dataset = "sorted";
            break;
        case 'v':
            dataset = "reverse";
            break;
        case 'q':
            algorithm = "quicksort";
            break;
        case 's':
            algorithm = "selection";
            break;
        case 'i':
            algorithm = "insertion";
            break;
        case 'n':
            algorithm = "none";
            break;
        }
    }
    argc -= optind;
    argv += optind;

    const int size = argc > 0 ? atoi(argv[0]) : 10000;
    int* data = new int[size];


    if (dataset == "sorted") {
        for (int i = 0; i < size; ++i) {
            data[i] = i;
        }
    }
    else if (dataset == "reverse") {
        for (int i = 0; i < size; ++i) {
            data[i] = size - i - 1;
        }
    }
    else if (dataset == "random") {
        for (int i = 0; i < size; ++i) {
            data[i] = rand() % size;
        }
    }

    if (algorithm == "quicksort") {
        quickSort(data, data + size);
    }
    else if (algorithm == "selection") {
        selectionSort(data, data + size);
    }
    else if (algorithm == "insertion") {
        insertionSort(data, data + size);
    }

    for (int i = 1; i < size; i++) {
        if (data[i] < data[i - 1]) {
            cout << "Oops!" << '\n';
            exit(1);
        }
    }

    cout << "OK" << '\n';
    cout << "Algorithm:   " << algorithm << '\n';
    cout << "Data set:    " << dataset << '\n';
    cout << "Size:        " << size << '\n' << '\n';
    // Uncomment for level 3 and 4
    cout << "Comparisons: " << comparisons << '\n';
    cout << "Swaps:       " << swaps << '\n';

    delete[] data;
    return 0;
}
