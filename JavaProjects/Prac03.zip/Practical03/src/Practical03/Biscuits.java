package Practical03;
/*
 *  Joshua Hartnett
 *  File: Biscuits.java
 *  Created on  25/08/2021,  12:00 PM
 *
 *  This program will read in a user input which will be a total number of biscuits. The program will then output the number
 *  of packets of biscuits, boxes of biscuits, leftover packets and leftover biscuits. This code is lengthy due to it having
 *  multiple different outcomes. The output changes based on the number of leftover biscuits, etc.
 */

import java.util.Scanner;

public class Biscuits {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        // declare any variables here
        int num1;
        int packets;
        int box;
        int leftoverPackets;
        int leftoverBiscuit;
        String result = "";

        // prompt for the number of biscuits
        System.out.print("Enter the number of biscuits: ");
        num1 = scan.nextInt();

        // calculate the number of packets and leftover biscuits
        packets = num1 / 12;
        leftoverBiscuit = num1 % 12;

        // calculate the number of boxes and leftover packets
        box = packets / 30;
        leftoverPackets = packets % 30;

        // output the results
        if (box >= 2) {
            if(leftoverPackets >= 2) {
                if(leftoverBiscuit >= 2) {
                    result = ("There are " + packets + " packets of biscuits: " + box + " boxes with " + leftoverPackets + " leftover packets and " + leftoverBiscuit + " leftover biscuits");
                } else if(leftoverBiscuit == 1) {
                    result = ("There are " + packets + " packets of biscuits: " + box + " boxes with " + leftoverPackets + " leftover packets and " + leftoverBiscuit + " leftover biscuit");
                } else if(leftoverBiscuit == 0) {
                    result = ("There are " + packets + " packets of biscuits: " + box + " boxes with " + leftoverPackets + " leftover packets and no leftover biscuits");
                }
            } else if(leftoverPackets == 1) {
                if(leftoverBiscuit >= 2) {
                    result = ("There are " + packets + " packets of biscuits: " + box + " boxes with " + leftoverPackets + " leftover packet and " + leftoverBiscuit + " leftover biscuits");
                } else if(leftoverBiscuit == 1) {
                    result = ("There are " + packets + " packets of biscuits: " + box + " boxes with " + leftoverPackets + " leftover packet and " + leftoverBiscuit + " leftover biscuit");
                } else if(leftoverBiscuit == 0) {
                    result = ("There are " + packets + " packets of biscuits: " + box + " boxes with " + leftoverPackets + " leftover packet and no leftover biscuits");
                }
            } else if(leftoverPackets == 0) {
                if(leftoverBiscuit >= 2) {
                    result = ("There are " + packets + " packets of biscuits: " + box + " boxes with no leftover packets and " + leftoverBiscuit + " leftover biscuits");
                } else if(leftoverBiscuit == 1) {
                    result = ("There are " + packets + " packets of biscuits: " + box + " boxes with no leftover packets and " + leftoverBiscuit + " leftover biscuit");
                } else if(leftoverBiscuit == 0) {
                    result = ("There are " + packets + " packets of biscuits: " + box + " boxes with no leftover packets and no leftover biscuits");
                }
            }
        }
        if (box == 1) {
            if(leftoverPackets >= 2) {
                if(leftoverBiscuit >= 2) {
                    result = ("There are " + packets + " packets of biscuits: " + box + " box with " + leftoverPackets + " leftover packets and " + leftoverBiscuit + " leftover biscuits");
                } else if(leftoverBiscuit == 1) {
                    result = ("There are " + packets + " packets of biscuits: " + box + " box with " + leftoverPackets + " leftover packets and " + leftoverBiscuit + " leftover biscuit");
                } else if(leftoverBiscuit == 0) {
                    result = ("There are " + packets + " packets of biscuits: " + box + " boxes with " + leftoverPackets + " leftover packets and no leftover biscuits");
                }
            } else if(leftoverPackets == 1) {
                if(leftoverBiscuit >= 2) {
                    result = ("There are " + packets + " packets of biscuits: " + box + " box with " + leftoverPackets + " leftover packet and " + leftoverBiscuit + " leftover biscuits");
                } else if(leftoverBiscuit == 1) {
                    result = ("There are " + packets + " packets of biscuits: " + box + " box with " + leftoverPackets + " leftover packet and " + leftoverBiscuit + " leftover biscuit");
                } else if(leftoverBiscuit == 0) {
                    result = ("There are " + packets + " packets of biscuits: " + box + " box with " + leftoverPackets + " leftover packet and no leftover biscuits");
                }
            } else if(leftoverPackets == 0) {
                if(leftoverBiscuit >= 2) {
                    result = ("There are " + packets + " packets of biscuits: " + box + " box with no leftover packets and " + leftoverBiscuit + " leftover biscuits");
                } else if(leftoverBiscuit == 1) {
                    result = ("There are " + packets + " packets of biscuits: " + box + " box with no leftover packets and " + leftoverBiscuit + " leftover biscuit");
                } else if(leftoverBiscuit == 0) {
                    result = ("There are " + packets + " packets of biscuits: " + box + " box with no leftover packets and no leftover biscuits");
                }
            }
        }

        if (box == 0) {
            if(leftoverPackets >= 2) {
                if(leftoverBiscuit >= 2) {
                    result = ("There are " + packets + " packets of biscuits: no boxes with " + leftoverPackets + " leftover packets and " + leftoverBiscuit + " leftover biscuits");
                } else if(leftoverBiscuit == 1) {
                    result = ("There are " + packets + " packets of biscuits: no boxes with " + leftoverPackets + " leftover packets and " + leftoverBiscuit + " leftover biscuit");
                } else if(leftoverBiscuit == 0) {
                    result = ("There are " + packets + " packets of biscuits: no boxes boxes with " + leftoverPackets + " leftover packets and no leftover biscuits");
                }
            } else if(leftoverPackets == 1) {
                if(leftoverBiscuit >= 2) {
                    result = ("There are " + packets + " packets of biscuits: no boxes with " + leftoverPackets + " leftover packet and " + leftoverBiscuit + " leftover biscuits");
                } else if(leftoverBiscuit == 1) {
                    result = ("There are " + packets + " packets of biscuits: no boxes with " + leftoverPackets + " leftover packet and " + leftoverBiscuit + " leftover biscuit");
                } else if(leftoverBiscuit == 0) {
                    result = ("There are " + packets + " packets of biscuits: no boxes with " + leftoverPackets + " leftover packet and no leftover biscuits");
                }
            } else if(leftoverPackets == 0) {
                if(leftoverBiscuit >= 2) {
                    result = ("There are " + packets + " packets of biscuits: no boxes with no leftover packets and " + leftoverBiscuit + " leftover biscuits");
                } else if(leftoverBiscuit == 1) {
                    result = ("There are " + packets + " packets of biscuits: no boxes with no leftover packets and " + leftoverBiscuit + " leftover biscuit");
                } else if(leftoverBiscuit == 0) {
                    result = ("There are " + packets + " packets of biscuits: no boxes with no leftover packets and no leftover biscuits");
                }
            }
        }

        System.out.println(result);
    }

}
