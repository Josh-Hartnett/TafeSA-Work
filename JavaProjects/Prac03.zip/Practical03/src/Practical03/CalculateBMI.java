package Practical03;

/*
 *  Joshua Hartnett
 *  File: CalculateBMI.java
 *  Created on  24/08/2021,  5:04 PM
 *
 *  This program will read in a user input which will be the users height and weight,
 *  then these values will be used to calculate the BMI (Body Mass Index) category.
 */

import java.text.DecimalFormat;
import java.util.Scanner;

public class CalculateBMI {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        double weight, height;
        String result;

        //Prompt the user to enter their weight in kilograms
        System.out.println("Please enter your weight in kilograms");
        weight = scan.nextDouble();

        //Prompt the user to enter their height in metres
        System.out.println("Please enter your height in metres");
        height = scan.nextDouble();


        // Calculate BMI
        double bmi = weight / (height * height);

        if(bmi < 18.5) {
            result = "Your BMI is " + String.format("%.1f",bmi) + ", which means you are in the underweight range.";
        } else if (bmi >= 18.5 && bmi <= 24.9) {
            result = "Your BMI is " + String.format("%.1f",bmi) + ", which means you are in the normal range.";
        } else if (bmi >= 25.0 && bmi <= 29.9) {
            result = "Your BMI is " + String.format("%.1f",bmi) + ", which means you are in the overweight range.";
        } else {
            result = "Your BMI is " + String.format("%.1f",bmi) + ", which means you are in the obese range.";
        }
        // Display the result
        System.out.println(result);
    }
}
