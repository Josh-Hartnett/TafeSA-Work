package Practical03;
/*
 *  Joshua Hartnett
 *  File: Calculating.java
 *  Created on  25/08/2021,  12:00 PM
 *
 *  This program will read in a user input which will be a number within the range of 0-10. Then a random integer within
 *  the same range will be generated. The user will be prompted to select either 0, 1 or 2  which will then calculate the users
 *  equation with the randomly generated number and their own.
 */

import java.util.Scanner;

public class Calculating {

    public static void main(String[] args) {
        Scanner scan = new Scanner (System.in);
        int inputNumber;
        int randomNumber = (int)(Math.random() * 10) + 1; //Create a random number between 1 and 10
        int menuNumber;

        //Get users number between 0 and 10
        System.out.println("Please enter an integer from 0-10");
        inputNumber = scan.nextInt();

        //If the users number is not between 0 and 10, ask them to restart
        if(inputNumber > 10 || inputNumber < 0) {
            System.out.println("Please restart and enter an integer between 0-10");
        } else if (inputNumber > 0){ //We know this will be true if the user gets to this point, then it will ask what the user would like to happen.
            System.out.println("Please enter 0 for addition, 1 for subtraction or 2 for multiplication");
            menuNumber = scan.nextInt();

            //If the user choose a number that wasn't between 0-2, then ask them to restart.
            if(menuNumber >= 3 || menuNumber < 0) {
                System.out.println("Please restart and enter 0 for addition, 1 for subtraction or 2 for multiplication");
            } else if (menuNumber == 0) { //If the user choose addition, output the random number and user input number
                System.out.println("Your equation is: " + inputNumber + " + " + randomNumber + " = " + (inputNumber + randomNumber));
            } else if (menuNumber == 1) {
                System.out.println("Your equation is: " + inputNumber + " - " + randomNumber + " = " + (inputNumber - randomNumber));
            } else if (menuNumber == 2) {
                System.out.println("Your equation is: " + inputNumber + " * " + randomNumber + " = " + (inputNumber * randomNumber));
            }
        }
        }
}