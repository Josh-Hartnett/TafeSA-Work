/*
 *  Joshua Hartnett
 *  File: NumberEvaluation.java
 *  Created on  24/08/2021,  5:04 PM
 *
 *  This program will read in a users number, then tell the user if it was a positive, negative or zero, as well as
 *  telling the user if that number is even or odd.
 */
package Practical03;

import java.util.Scanner;

/*
 *  Joshua Hartnett
 *  File: NumberEvaluation.java
 *  Created on  24/08/2021,  5:04 PM
 *
 *  This program will read in a users input, which will be a number. Then, calculations will be done to determine whether
 *  the users number is a positive, negative or 0 as well as whether it is an even or odd number. Zero will result in a even output.
 */

public class NumberEvaluation {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        // prompt the user for a number
        int num1;
        System.out.println("Please enter a number: ");
        num1 = scan.nextInt();

        // determine whether it is positive, negative, or zero
        if(num1 >= 1) {
            System.out.println("Positive");
        } else if (num1 <= -1) {
            System.out.println("Negative");
        } else if (num1 == 0) {
            System.out.println("Zero");
        }
        // determine whether it is odd or even
        if(num1 % 2 == 0) {
            System.out.println("The number is even");
        } else {
            System.out.println("The number is odd");
        }
    }

}
