package Practical03;

/*
 *  Joshua Hartnett
 *  File: Ticket.java
 *  Created on  24/08/2021,  5:04 PM
 *
 * This program will read in the users age, and decide how much a ticket costs.
 */
import java.util.Scanner;

public class Ticket {

    public static void main(String[] args) {
        double age;
        double ticket = 12;
        Scanner keyboard = new Scanner(System.in);

        System.out.println("Please enter your age ");
        age = keyboard.nextDouble();

        if (age <= 8 || age >= 65) { //The or comparison operator was added (||) so that the age can be less than or equal to 8, or greater than or equal to 65
            ticket = 6; //If either condition is met, the ticket = 6
        }
        System.out.println("Your ticket costs $" + ticket);
    }
}
