package Practical05;

import java.lang.String;

public class Frog {

    private String name = "Name_not_set";
    private int id = -1; // -1 used to indicates it has not been set
    private int age = 0; //0 used to indicate not set

    Frog(String theName, int theId, int theAge) {
        name = theName;
        id = theId;
        age = theAge;
    }

    public void printAgeGroup() { //Print age group will run if else statements to determine the output.
        if(age >= 0 && age <= 20) { //If the age is between 0 and 20 then it will output age group is young
            System.out.println("Age group is young");
        } else if(age >= 21 && age <= 50) {
            System.out.println("Age group is juvenile");
        } else {
            System.out.println("Age group is adult");
        }
    }

    public void reversedName() {
        for(int i = 0; i < name.length(); i++) { //This for loop iterates to the length of the frogs name.
            switch(name.charAt(i)) { //If the character within the name at the current index is equal to any of the switch cases....
                case 'a': //.... It will print out a new letter or the original letter.
                    System.out.print('i');
                    break;
                case 'n':
                    System.out.print('i');
                    break;
                case 'r':
                    System.out.print('o');
                    break;
                case 'F':
                    System.out.print('o');
                    break;
                default:
                    System.out.print(name.charAt(i));
            }
        }
        System.out.println();
    }

    void print() {
        System.out.println("**** Start of print method ******");
        System.out.println("Frog's name is " + name);
        System.out.println("Id  is " + id);
    }
}
