package Practical05;

public class FrogProgram {

    public static void main(String[] args) {
        //Frog myFrog = new Frog();  // create a Frog object
        //myFrog.name = "Fred";      //###
        Frog myFrog = new Frog("Fred", 1000, 22); //Declare first frog instance


        //Task 1
        //myFrog.id = 1000;

        //Task 2
        //myFrog.age = 22;
        myFrog.print(); //Print details of first frog and age group
        myFrog.printAgeGroup();

        //Task 3
        Frog myFrog2 = new Frog("Fran", 1001, 75); //Declare second frog instance
        myFrog2.print(); //Print details of first frog and age group
        myFrog2.printAgeGroup();

        //Task 4
        myFrog.reversedName(); //Output 'reversed name' of both frogs
        myFrog2.reversedName();

    }  // end of main
} // end of FrogProgram

