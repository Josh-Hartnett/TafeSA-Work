package Practical07;

public class ArrayTask {

    public static void main(String[] args) {
        /*
        int[] intList = {5, 20, 32, 7, 9};
        int[] copy = new int[5];
        int sum = 0;
        int sum2 = 0;

        for (int i = 0; i < intList.length; i++) {
            copy[i] = intList[i];
        }

        //Modify i=0; i < intList.length; i++ to:
        for (int i = intList.length-1; i >= 0; i--) {
            intList[i] = intList[i] + 1;
            System.out.println("intList[" + i + "]: " + intList[i]);
            sum = sum + intList[i]; //This adds the current array index to the sum.
            sum2 = sum2 + copy[i];
        }
        System.out.println("Sum of intList = " + sum); //Output sum.
        System.out.println("Sum of copy = " + sum2);

         Commented out above are the checkpoints 32-34, and below is checkpoint 35.
         For Checkpoint 35 I created a new IntList class found in the IntList.java file.
         */


        IntList list1 = new IntList(4);

        list1.printList();

        list1.insertAtEndofList(42);
        list1.printList();
        list1.insertAtEndofList(2);
        list1.printList();

        System.out.println(list1.getElementAt(3));
        System.out.println(list1.getElementAt(-1));
        System.out.println(list1.getElementAt(1));

        list1.insertAtEndofList(7);
        list1.insertAtEndofList(9);
        list1.printList();
        list1.insertAtEndofList(100);
    }
}
