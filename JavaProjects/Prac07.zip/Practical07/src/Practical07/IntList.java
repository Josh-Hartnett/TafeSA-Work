package Practical07;

public class IntList {
    int[] list;
    int listLength = 0;

    //Set list and list size
    public IntList(int size){
        list = new int[size];
    }

    //Print list
    public void printList() {
        //If the listLength is == to 0, the array is considered empty as no values have been inserted. However if we were
        //print the array, it would print 4 values of 0.
        if (listLength == 0) {
            System.out.println("List is empty");
        } else {
            //Here we write for all values not equal to 0, print. This is another way we determine whether that index is empty.
            System.out.println("Printing list...");
            for (int i = 0; i < list.length; i++) {
                if(list[i] != 0) {
                    System.out.println("Element " + i + " = " + list[i]);
                }
            }
        }
    }

    public void insertAtEndofList(int num) {
        //If the array has reached it maximum limit, inform the user of an error.
        if(listLength == list.length) {
            System.out.println("Insertion of " + num + " failed");
        } else {
            //Otherwise, insert the users value into the array.
            list[listLength] = num;
            listLength++;
            System.out.println(num + " inserted");
        }
    }


    public String getElementAt(int num) {
        String result = null;
        //If the value is not equal to the listLength -1, meaning if the user value is not equal to a current index of the array
        if(num != listLength - 1) {
            result = "Invalid index: " + num + "\n0";
        } else {
            //Otherwise, print the index at the users index.
            result = "" + list[num];
        }
        return result;
    }
}
