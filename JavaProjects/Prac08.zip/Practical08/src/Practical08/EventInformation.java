package Practical08;

public class EventInformation {

    private String eventTime;
    private int eventDatum = 0;

    EventInformation(String eventTime, int eventDatum) {
        this.eventTime = eventTime;
        this.eventDatum = eventDatum;
    }

    String getEventTime() {
        return eventTime;
    }
    int getEventDatum() {
        return eventDatum;
    }
}
