package Practical08;

// Program to record the times at which events occur at a number of
// locations. No continunity or error checking is performed.

//RecordEvents creates a single recorder, records 2 events
// and prints out the complete list of events

/*
----- 12/10/2021 - Joshua Hartnett -----------
 */
public class RecordEvents {

    public static void main(String args[]) {
        Recorder r1 = new Recorder(100, 100, "Wombat Detection");
        r1.recordEvent("10:53", 20);
        r1.recordEvent("10:59", 20);
        r1.recordEvent("11:05", 20);
        r1.recordEvent("12:59");
        r1.recordEvent("13:59");
        r1.recordEvent("14:06");
        r1.printEvents();
    }
}
