package Practical08;

// A Recorder object can store up to 5 events
// The time of each event is stored as a string
// The constructor receives the coordinates of the recorder and the name
// of the event type as parameters


import jdk.jfr.Event;

public class Recorder {

    int xPos, yPos;
    final int EVENT_MAX = 10;
    String eventType;
    //Change declaration of event to be an array of EventInformation
    EventInformation[] event = new EventInformation[EVENT_MAX];

    int xevent = 0;  // keeps track of how many events have occurred

    Recorder(int xPos, int yPos, String eventType) {
        this.xPos = xPos;
        this.yPos = yPos;
        this.eventType = eventType;
    }
    Recorder(int xPos, int yPos, String eventType, int datum) {
        this.xPos = xPos;
        this.yPos = yPos;
        this.eventType = eventType;
    }

    public void recordEvent(String eventTime, int datum) {
        if(xevent == EVENT_MAX) {
            System.out.println("Event log overflow - terminating");
            System.exit(1);
        }
        event[xevent] = new EventInformation(eventTime, datum);
        xevent++;
    }
    public void recordEvent(String eventTime) {
        if(xevent == EVENT_MAX) {
            System.out.println("Event log overflow - terminating");
            System.exit(1);
        }
        event[xevent] = new EventInformation(eventTime, 10);
        xevent++;
    }

    void printEvents() {
        System.out.println("Record of " + eventType + " events at [" + xPos + "," + yPos + "]");
        // Task 1:
        // Add a for loop below this line to print out each event (see task 1 spec)
        // Note that not all 5 elements of the array are necessarily used
        // The variable xevent is always one bigger than the index of the last 
        // event recorded. For example, after two events have been recorded (as
        // in the method main above) the value of xevent will be 2.

        //Checkpoint 37
        for(int i = 0; i < xevent; i++) {
            System.out.println("Event number " + i + " was recorded at " + event[i].getEventTime() + " with datum = " + event[i].getEventDatum());
        }
    }

}
