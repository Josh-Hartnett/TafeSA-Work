package Practical09;

public class Car extends Vehicle {

    String type;
    String model;
    int capacity;

    Car(int theCapacity, String theMake, String theType, String theModel) {
        super(theCapacity, theMake);

        capacity = theCapacity;
        type = theType;
        model = theModel;
    }

    void print() {
        super.print();
        System.out.println("  type = " + type);
        System.out.println("  model = " + model);
    }

    @Override
    void setCapacity(int newCapacity) {
        System.out.println("Cannot change capacity of car");
    }
}

