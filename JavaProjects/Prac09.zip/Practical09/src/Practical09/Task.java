package Practical09;

public class Task {

   public static void main(String[] args) {
      /*Car car1 = new Car(1200,"Holden","sedan","Barina");
      Vehicle v1 = new Vehicle(1500, "Mazda");
      v1.setCapacity(1600);
      v1.print();
      car1.setCapacity(1600);
      car1.print();*/

      VehicleDB db = new VehicleDB () ;
      db.addVehicle(new Car(1200," Holden ", " sedan ", " Barina "));
      db.addVehicle(new Vehicle(1500,"Mazda "));
      db.print() ;
   }
}