package Practical09;

public class Vehicle {  // base class

   int capacity;
   String make;

   Vehicle(int theCapacity, String theMake) {
      capacity = theCapacity;
      make = theMake;
   }


   void print() {
      System.out.println("Vehicle Info:");
      System.out.println("  capacity = " + capacity + "cc" );
      System.out.println("  make = " + make );
   }

   void setCapacity(int capacity) {
      this.capacity = capacity;
   }
}
