package Practical09;

public class VehicleDB {

    Vehicle[] db = new Vehicle[100];
    int count = 0;


    public void addVehicle(Car car) {
        db[count] = car;
        count++;
    }

    void addVehicle(Vehicle vehicle) {
        db[count] = vehicle;
        count++;
    }

    void print() {
        System.out.println("=== Vehicle Data Base ===");
        for(int i = 0; i < count; i++) {
            db[i].print();
        }
    }

}
