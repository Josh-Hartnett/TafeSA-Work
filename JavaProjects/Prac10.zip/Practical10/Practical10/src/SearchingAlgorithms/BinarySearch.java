package SearchingAlgorithms;

import CoreApplication.*;

public class BinarySearch extends SearchAlgorithm{
    public BinarySearch(DataVisualiserApplication main) {
        super("Binary Search", main);
        sleepMultiplier = 15;
    }

    @Override
    public void performAlgorithm() {
        foundIndex = binarySearch();
        dataSet.setStatusLabel(getSearchSummaryString());
    }

    private int binarySearch() {
        int low = 0;
        int high = dataElements.length -1;

        while(low <= high) {

            int mid = (low + high) / 2;
            highlightAndLog(low, high, mid);

            if(dataElements[mid].getValue() == target.getValue()) {
                return mid;
            }

            if(dataElements[mid].getValue() < target.getValue()) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }

            if(low > high) {
                System.out.println("Element not found!");
                return -1;
            }
        }
        return -1;
    }
}
