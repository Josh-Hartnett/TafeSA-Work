package SortingAlgorithms;

import CoreApplication.*;

public class InsertionSort extends SortAlgorithm{
    public InsertionSort(DataVisualiserApplication main) {
        super("Insertion Sort", main);
    }

    @Override
    public void performAlgorithm() {
        int indexA, indexB;
        for(indexA = 1; indexA < dataElements.length; indexA++) {
            assign(dataSet.getTempValueElement(), dataElements[indexA]);
            indexB = indexA;
            while(indexB > 0 && compare(dataSet.getTempValueElement(), dataElements[indexB-1])) {
                assign(dataElements[indexB],dataElements[indexB-1]);
                swaps++;
                updateStatusText();
                indexB--;
            }

            assign(dataElements[indexB], dataSet.getTempValueElement());
            swaps++;
            updateStatusText();
            //Assign works as storing the second value into the first

        }
    }
}
