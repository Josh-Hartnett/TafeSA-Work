package SortingAlgorithms;

import CoreApplication.*;

public class SelectionSort extends SortAlgorithm{
    public SelectionSort(DataVisualiserApplication main) {
        super("Selection Sort", main);
    }


    @Override
    public void performAlgorithm() {
        int indexA, indexB, min;
        for(indexA = 0; indexA < dataElements.length -1; indexA++) {
            min = indexA;
            for(indexB = indexA + 1; indexB < dataElements.length; indexB++) {
                if(compare(indexB, min)) {
                    min = indexB;
                }
            }
            if(min != indexA) {
                swap(indexA, min);
            }
        }
    }
}
